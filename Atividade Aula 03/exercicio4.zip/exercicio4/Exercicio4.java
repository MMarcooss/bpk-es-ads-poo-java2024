package exercicio4;

public class Exercicio4 {
    public static void main(String[] args) {
        Contabancaria conta1 = new Contabancaria(01, 20000);
        System.out.println(conta1.getSaldo());
    }
}
